<?php
//echo "hello";
    $hName='localhost'; // host name

    $uName='root';   // database user name

    $password='M$p@1234';   // database password

    $dbName = "autosave"; // database name

    $conn= mysqli_connect($hName,$uName,$password,"$dbName");

      if($conn){
        echo"success";
         
      }
      else{
         die('Could not Connect MySql Server:' .mysql_error());
      }

  $name=$_POST['name'];

  $email=$_POST['email'];
 
  $phone=$_POST['phone'];
 
  $city=$_POST['city'];

  $sql = "INSERT INTO `crud`( `name`, `email`, `phone`, `city`) 
  VALUES ('$name','$email','$phone','$city')";
  
  if (mysqli_query($conn, $sql)) {
    echo json_encode(array("statusCode"=>200));
  } 
  else {
    echo json_encode(array("statusCode"=>201));
  }
  mysqli_close($conn);
?>
 